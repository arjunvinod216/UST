
import pymongo
from flask import Flask, redirect, render_template, request, session
from flask_pymongo import PyMongo

app = Flask(__name__,template_folder='templetes')

#mongodb://localhost:27017
app.config['MONGO_URI'] = 'mongodb://localhost:27017/kitchenCollection'
mongo = PyMongo(app)
holder = list()

@app.route('/')
def hello_world():
    for i in collection.find():
        holder.append(i)
    return render_template("login.html")

@app.route('/book',methods=['GET','POST'])
def book():
    
    if request.method=="POST":
        #kitchendata={'Table_Num': 1, 'Food':'yes','Action':'Booked','Resolve':'Delivered'}
        Table=request.form['Table_Num']
        print(Table)
        Food=request.form['food']
        print(Food)
        input_dict={"Table_Num":Table,"food":Food,"Action":"Booked",'Resolve':'Preparing','Rating':'Nil'}
        if collection1.count_documents({'Table_Num':  Table}, limit=1) != 0:
            return render_template('book.html')
        else:
            collection1.insert_one(input_dict)
            alldoc=collection1.find()
            return render_template('home.html',alldoc=alldoc)
    return render_template("book.html")

@app.route('/dashboard')
def hello():
    alldoc=collection1.find()
    #print(alldoc)
    return render_template('home.html',alldoc=alldoc)

@app.route('/update/<string:Table_Num>')
def up(Table_Num):
    #print(Table_Num)
    #collection1.update_one({'Table_Num':Table_Num},{'$set':{'Resolve':'Delivered'}})
    myquery = {"Table_Num":Table_Num}
    newvalues = {"$set":{"Resolve":"Delivered"}}
    collection1.update_one(myquery, newvalues)
    alldoc=collection1.find()
    return render_template('home.html',alldoc=alldoc)

@app.route('/delete/<string:Table_Num>')
def delete(Table_Num):
    myquery = {"Table_Num":Table_Num}
    collection1.delete_one(myquery)
    alldoc=collection1.find()
    return render_template('home.html',alldoc=alldoc)

@app.route('/rating/<string:Table_Num>',methods=['GET','POST'])
def rate(Table_Num):
    if request.method=="POST":
        rating=request.form['rating1']
        print(rating)
        myquery = {"Table_Num":Table_Num}
        newvalues = {"$set":{"Rating":rating}}
        collection1.update_one(myquery, newvalues)
        alldoc=collection1.find()
        return render_template('home.html',alldoc=alldoc)
    alldoc=collection1.find()
    return render_template('home.html',alldoc=alldoc)

@app.route('/',methods=['GET','POST'])
def login():

    if request.method=='POST':
        for key,val in request.form.items():
            if key == 'username':
                username = val
            else:
                password = val
        filtered=[d for d in holder if condition(d,username, password)]
        #print(filtered)
    if filtered:
        return redirect('/dashboard')
    else:
        print("Wrong Username or Pasword")
        return redirect('/')
        

@app.route('/register',methods=['GET','POST'])
def register():
    if request.method=="POST":
        first_name=request.form['fname']
        #print(first_name)
        last_name=request.form['lname']
        #print(last_name)
        user_name=request.form['username']
        #print(user_name)
        password=request.form['password']
        #print(password)
        input_dict={"first_name":first_name,"last_name":last_name,"username":user_name,"password":password}
        if collection.count_documents({'username':  user_name}, limit=1) != 0:
            return render_template('register.html')
        else:
            collection.insert_one(input_dict)
            return redirect("/")
    return render_template("register.html")
    
    
def condition(dict, username, password):
    return dict['username'] == username and dict['password'] == password


if __name__=='__main__':
    client = pymongo.MongoClient("mongodb://localhost:27017")
    print(client)
    db=client['kitchenDB']
    collection=db['kitchenCollection']
    db1=client['FoodDB']
    collection1=db1['FoodCollection']
    #kitchendata={'Table_Num': 1, 'Food':'yes','Action':'Booked','Resolve':'Delivered'}
    #collection1.insert_one(kitchendata)
    for i in collection.find():
        holder.append(i)
    app.run(host = '0.0.0.0', debug=True, port=8080)

